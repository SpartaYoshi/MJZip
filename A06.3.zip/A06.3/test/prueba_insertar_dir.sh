rm bottle.mj
#Casos de prueba
#1
echo Caso de prueba 1:
../insertmypackzip bottle.mj ../testfiles_insertar_dir/dir1/ 0
#2
echo Caso de prueba 2:
../insertmypackzip bottle.mj ../testfiles_insertar_dir/dir1/ -1
#3
echo Caso de prueba 3:
../insertmypackzip bottle.mj ../testfiles_insertar_dir/dir1/ 2
