#8
rm bottle.mj
../../insertmypackzip bottle.mj ../testfiles/dir1_rec/dir1_rec1 4


