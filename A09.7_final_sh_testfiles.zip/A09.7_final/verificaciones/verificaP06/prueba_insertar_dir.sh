rm bottle.mj
#Casos de prueba
#1
##echo Caso de prueba 1:
../../insertmypackzip bottle.mj ../testfiles/dir1/ 0
#2
##echo Caso de prueba 2:
../../insertmypackzip bottle.mj ../testfiles/dir1/ -1
#3
##echo Caso de prueba 3:
../../insertmypackzip bottle.mj ../testfiles/dir1/ 2
#4
../../insertmypackzip bottle.mj ../testfiles/vacio.txt 16
../../insertmypackzip bottle.mj ../testfiles/dir_vacio/ 16
#5
rm bottle.mj
../../insertmypackzip bottle.mj ../testfiles/dir2/ 0
../../insertmypackzip bottle.mj ../testfiles/dir1/ 31
#6
../../insertmypackzip bottle.mj ../testfiles/dir2/ 35
#7
rm bottle.mj
for i in {0..31}
do
../../insertmypackzip bottle.mj ../testfiles/dir2/ $i
done
../../insertmypackzip bottle.mj ../testfiles/dir1/ -1
##recursivo


