#1
../../insertmypackzip bottle.mj ../testfiles/enlaces/infi 0
#2
../../insertmypackzip bottle.mj ../testfiles/enlaces 4
#3
../../insertmypackzip bottle.mj ../testfiles/enlaces/enlace_de_enlace 20
hexdump -C bottle.mj
rm bottle.mj


