int def(int  fd_source, int fd_dest, int level);

int inf(int fd_source, int fd_dest);
