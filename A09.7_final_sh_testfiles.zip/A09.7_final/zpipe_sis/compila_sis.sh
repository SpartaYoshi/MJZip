gcc zpipe_sis.c -lz -o zpipe_sis
